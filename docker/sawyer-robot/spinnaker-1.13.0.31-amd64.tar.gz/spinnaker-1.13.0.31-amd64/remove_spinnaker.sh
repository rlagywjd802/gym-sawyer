#!/bin/bash

MAJ_VER=1

MY_PROMPT='$ '
MY_YESNO_PROMPT='(y/n)$ '

echo "Removing Spinnaker packages...";

dpkg -r spinnaker-doc
dpkg -r spinnaker
dpkg -r spinupdate$MAJ_VER-dev
dpkg -r spinupdate$MAJ_VER
dpkg -r libspinvideo-c$MAJ_VER-dev
dpkg -r libspinvideo-c$MAJ_VER
dpkg -r libspinvideo$MAJ_VER-dev
dpkg -r libspinvideo$MAJ_VER
dpkg -r libspinnaker-c$MAJ_VER-dev
dpkg -r libspinnaker-c$MAJ_VER
dpkg -r spinview-qt$MAJ_VER-dev
dpkg -r spinview-qt$MAJ_VER
dpkg -r libspinnaker$MAJ_VER-dev
dpkg -r libspinnaker$MAJ_VER
dpkg -r libspinvideoencoder$MAJ_VER

echo "Removing rules file";

if [ -e "/etc/udev/rules.d/40-flir-spinnaker.rules" ]
then
    sudo rm /etc/udev/rules.d/40-flir-spinnaker.rules
fi

echo "Complete";

exit 0
