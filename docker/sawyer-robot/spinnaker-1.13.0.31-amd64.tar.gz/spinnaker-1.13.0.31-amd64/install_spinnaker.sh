#!/bin/bash

set -o errexit

MY_PROMPT='$ '
MY_YESNO_PROMPT='(y/n)$ '

# version of the software
MAJOR_VERSION=1
MINOR_VERSION=7
RELEASE_TYPE=0
RELEASE_BUILD=6
INFORMATIONAL_VERSION=1.7.0.6
RELEASE_TYPE_TEXT=Release

echo "Installing Spinnaker packages...";

dpkg -i libspinvideoencoder-*.deb
dpkg -i libspinnaker-*.deb
dpkg -i libspinvideo-*.deb
dpkg -i spinview-qt-*.deb
dpkg -i spinupdate-*.deb
dpkg -i spinnaker-*.deb

exit 0
